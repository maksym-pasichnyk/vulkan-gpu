# CMake files overview:

- `ranges_options.cmake`: All options to configure the library.
- `ranges_env.cmake`: Detects the environment: operating system, compiler, build-type, ...
- `ranges_flags.cmake`: Sets up all compiler flags.
