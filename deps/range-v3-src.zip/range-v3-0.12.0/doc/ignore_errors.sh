#!/bin/bash
$* 2>/dev/null
exit 0
